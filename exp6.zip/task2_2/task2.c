/*----------------------------------------------------------------------------
 * Name:    Blinky.c
 * Purpose: LED Flasher for MPS2
 * Note(s): possible defines set in "options for target - C/C++ - Define"
 *            __USE_LCD    - enable Output on GLCD
 *            __USE_TIMER0 - use Timer0  to generate timer interrupt
 *                         - use SysTick to generate timer interrupt (default)
 *----------------------------------------------------------------------------
 * This file is part of the uVision/ARM development tools.
 * This software may only be used under the terms of a valid, current,
 * end user licence from KEIL for a compatible version of KEIL software
 * development tools. Nothing else gives you the right to use this software.
 *
 * This software is supplied "AS IS" without warranties of any kind.
 *
 * Copyright (c) 2015 Keil - An ARM Company. All rights reserved.
 *----------------------------------------------------------------------------*/

/* Standard includes. */
#include <stdio.h>
#include <string.h>
#include "CMSDK_CM4_FP.h"
typedef unsigned int            uint32_t; 
#include "task2.h"

/*----------------------------------------------------------------------------
  Main function
 *----------------------------------------------------------------------------*/


#define MACRO_CTRL 0xE000ED94
#define MACRO_RNR 0xE000ED98
#define MACRO_RBAR 0xE000ED9C
#define MACRO_RASR 0xE000EDA0
void vTaskStart( void *pvParameters )
{
	volatile unsigned int * pCTRL=(volatile unsigned int *)MACRO_CTRL;
	volatile unsigned int * pRNR=(volatile unsigned int *)MACRO_RNR;
	volatile unsigned int * pRBAR=(volatile unsigned int *)MACRO_RBAR;
	volatile unsigned int * pRASR=(volatile unsigned int *)MACRO_RASR;
	for(int i=0;i<8;i++){
		*pRNR=i;
		printf("befor: pRNR %d,pCTRL %d,pRBAR %08x,pRASR %08x\n",*pRNR,*pCTRL,*pRBAR,*pRASR);
	}
	*pCTRL=5;
	*pRNR=6;
	*pRBAR=0x40010000;
	*pRASR=0x01020009;  //1000000100000000000001001
	for(int i=0;i<8;i++){
		*pRNR=i;
		printf("after: pRNR %d,pCTRL %d,pRBAR %08x,pRASR %08x\n",*pRNR,*pCTRL,*pRBAR,*pRASR);
	}
	
  printf( "Attack test begin\n" );
  AttackTest();
  for(;;);
}

int main (void) {

	uint32_t a = 1658; // replace with your last 4-digital id 
    prvSetupHardware();
	xTaskCreate( vTaskStart, "Test2", 100, NULL, ( 1 | ( 0x80000000UL ) ), NULL );
    StartFreeRTOS(a);

	/* Will only get here if there was insufficient memory to create the idle
	task. */
	for(;;);

}




